let l = [] in
let l = 4::l in
let l = 3::l in
let l = 2::l in
let l = 1::l in
l
