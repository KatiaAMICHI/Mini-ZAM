(fun x -> (fun y -> (fun z -> if x then y else z) 64 ) 42 ) true
